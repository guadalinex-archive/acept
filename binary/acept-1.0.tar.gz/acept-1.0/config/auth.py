#!/usr/bin/env python

print "Ok"
