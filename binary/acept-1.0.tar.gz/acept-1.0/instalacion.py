#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

###Archivo crea directorios, archivos, actualiza fecha actual en fichero de configuracion
###y establece permisos adecuados en estructura de directorios tras la instalacion
###de la aplicacion

from inicSquid import *
from watcherSquid import *
from func import actualiza_campo
import os, os.path
import time

file_conf='/etc/watcherCat/watcherconf.xml'


if not os.path.isdir('/usr/squid/var'):
	os.makedirs('/usr/squid/var')

if not os.path.isdir('/usr/squid/var/logs'):
	os.makedirs('/usr/squid/var/logs')

if not os.path.isdir('/usr/squid/var/cache'):
	os.makedirs('/usr/squid/var/cache')

if not os.path.isdir('/usr/squid/var/rg'):
	os.makedirs('/usr/squid/var/rg')

if not os.path.isdir('/usr/squidGuard/log'):
	os.makedirs('/usr/squidGuard/log')

if not os.path.isdir('/var/lib/squidguard'):
	os.makedirs('/var/lib/squidguard')

if not os.path.isdir('/var/lib/squidguard/db'):
	os.makedirs('/var/lib/squidguard/db')

if not os.path.isdir('/opt/caton/acept-1.0/estadisticas'):
	os.makedirs('/opt/caton/acept-1.0/estadisticas')


examina_permisos(file_conf)
inic_direct_users(file_conf)
ublacklists(file_conf)
inic_squid_users(file_conf)
inic_sarg_users(file_conf)
apply_conf_squidguard(file_conf)

date=time.localtime()
act_date=time.strftime("%d%b%Y",date)
act_update=time.strftime("%d/%m/%Y",date)
act_fecha=time.strftime("%d %W %m %Y",date)

actualiza_campo('last_update', act_update, file_conf)
actualiza_campo('last_date',act_date,file_conf)
actualiza_campo('fecha',act_fecha,file_conf)

examina_permisos(file_conf)
