#!/usr/bin/python

from distutils.core import setup

setup(name='acept',
	version='1.0',
	description='Aplicacion para el control electronico paterno-materno',
	author='Maria D. Perez, Nestor Chacon Manzano',
	author_email='mshk@caton.es nchacon@caton.es',
	url='http://ws314.juntadeandalucia.es/repositorio/projects/acept/',
	py_modules=["avanzado","ayuda","confSquid","func_blacklists","func_navegacion","func","informes","inicSquid","mefiGlobal","watcherMods","watcherSquid","wizard"],
	scripts=['acept.py','gui.py','instalacion.py','mefistofelina.py'],
	data_files=[('/etc/watcherCat',['config/watcherconf.xml','config/asocia_contenidos','config/limpia_iptables']),('/usr/squid/etc',['config/squid_acept.conf','config/sarg_acept.conf']),('/opt/caton/acept-1.0',['config/auth.py'])],
	)
