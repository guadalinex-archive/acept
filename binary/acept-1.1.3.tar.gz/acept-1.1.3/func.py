# -*- coding: ISO-8859-1 -*-
#
# Fichero:	func.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 27 17:01:26 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)

###Archivo contiene modulos basicos que son comunes a casi la totalidad de la aplicacion
from mefiGlobal import *
from xml.dom import minidom

##Modulo extrae valor de campo especificado, se considera unico en archivo de configuracion
def consulta_campo(campo,file_conf):
    """Devuelve valor del campo especificado"""
    xmldoc=minidom.parse(file_conf)
    
    valor=xmldoc.getElementsByTagName(campo)[0].firstChild.data
    
    return str(valor)
    
    
##Modulo modifica valor de campo por el especificado
def actualiza_campo(campo,valor,file_conf):
    """Establece valor de campo especificado al indicado"""
    xmldoc=minidom.parse(file_conf)
    xmldoc.getElementsByTagName(campo)[0].firstChild.data=valor
    
    #escribe cambios realizados a archivo de configuracion
    f=open(file_conf,'w')
    f.write(xmldoc.toxml())
    f.close()
    
##Modulo comprueba si se esta monitorizando ese servicio para ese usuario, y esta
##activo
def servicio_activo(user,servicio,file_conf):
    """Devuelve True si el servicio esta definido, si el usuario tambien lo esta no siendo root
    y el servicio es monitorizado para dicho usuario y se encuentra activo"""
    from xml import xpath
    
    xmldoc=minidom.parse(file_conf)

    if xpath.Evaluate('/config/servicios/'+servicio,xmldoc)==[]:
        return False #servicio no monitorizado
    elif xpath.Evaluate('/config/usuarios/'+user,xmldoc)==[] or user.find('root')!=-1:
        return False # usuario no considerado o root
    elif xpath.Evaluate('/config/usuarios/'+user+'/'+servicio,xmldoc)==[]:
        return False #servicio no considerado para usuario
    elif xpath.Evaluate('/config/usuarios/'+user+'/'+servicio+'/activo',xmldoc)[0].firstChild.data=='1':
        return True
    else:
        return False
        
##Modulo comprueba si web activo para usuario 
def web_activo(user,file_conf):
    """Comprueba si el servicio web esta activo para el usuario """

    return servicio_activo(user,'web',file_conf)

    
##Modulo extrae lista de usuarios monitorizados en el sistema
##del archivo de configuracion de acept especificado
##Usada en funciones: cuenta_pg_users,trafico_usuario, pag_usuario,
##pag_cron, pag_nvisit, pag_trafic y pag_clave
def extrae_users(file_conf):
    """Devuelve lista de usuarios que aparecen definidos en archivo de configuracion"""
    from xml import xpath
    
    f=minidom.parse(file_conf)
    usuarios=[]
    for user in xpath.Evaluate('/config/usuarios/*', f):
        usuarios.append(str(user.localName))
    return usuarios
    
##Modulo comprueba si usuario especificado tiene alguna politica de acceso web definida
##en cuyo caso devuelve 1, sino devuelve 0
##Usada en:
def control_web_user(user,file_conf):
    """Comprueba si usuario tiene alguna politica de filtrado web definida, si es asi devuelve 1"""
    from xml import xpath
    
    doc=minidom.parse(file_conf)
    if xpath.Evaluate('/config/usuarios/'+user+'/web/denegado/*',doc)==[]:
        return 0
    else:
        return 1
        

##Modulo extrae lista de usuarios con servicio web monitorizado por squid en el sistema
##del archivo de configuracion de acept especificado
##Usada en funciones: cuenta_pg_users,trafico_usuario, pag_usuario,
##pag_cron, pag_nvisit, pag_trafic y pag_clave
def users_control_web(file_conf):
    """Devuelve lista de usuarios con politicas de filtrado web definidas"""
    from xml import xpath
    
    f=minidom.parse(file_conf)
    usuarios=[]
    for user in xpath.Evaluate('/config/usuarios/*', f):
        if xpath.Evaluate('/config/usuarios/'+user.localName+'/web/denegado/*',f)!=[]:
            usuarios.append(str(user.localName))
    return usuarios
        

##Modulo extrae lista de usuarios no-root con sesiones abiertas y web activo  
##usadas para incluir reglas para redireccion de squid
##llamada desde: apply_conf_squid(watcherSquid), configura_fw(watcherMods)
def users_conect(file_conf):
    """Devuelve lista de usuarios no-root con sesiones abiertas en el sistema, politicas de filtrado
   definidas y servicio web activo"""
    import commands
    #se extrae lista de usuarios conectados mediante orden 'who -q'
    #devuelve usuarios con sesiones abiertas y num. de sesiones
    orden='who -q'
    
    orden_executed=False
    while not orden_executed:
	try:
    		users=commands.getoutput(orden)
    	except IOError:
		pass
	else:
		orden_executed=True

    n_users=int(users[users.rfind('=')+1:]) #num de sesiones abiertas
    l_users=users.split(' ')
    
    #construye lista de usuarios no-root con sesiones abiertas y politicas de control web 
    controlados=[]

    for i in range(n_users):
        if l_users[i].find('root')==-1:
            try:
                n=controlados.index(l_users[i])
            except ValueError:
                if control_web_user(l_users[i], file_conf)==1 and web_activo(l_users[i],file_conf):#si tiene politicas de control web definidas se incluye
                    controlados.append(l_users[i])
               
    
    return controlados

###Modulo consulta puerto configurado para configuracion de squid del usuario indicado        
def squid_port_user(user,file_conf):
    """Devuelve puerto en el que se asigna escuche instancia de squid que corresponde a ese usuario"""
    from xml import xpath
    xmldoc = minidom.parse(file_conf)
    port=xpath.Evaluate('/config/usuarios/'+user+'/web/squid_pt',xmldoc)[0].childNodes[0].data
    
    return str(port)

    
def indice_mes(mes):
    """Devuelve indice numerico de mes indicado"""
    nombre=mes.capitalize()    

    if nombre.find('Jan')!=-1 or nombre.find('Ene')!=-1:
        return '01'
    if nombre.find('Feb')!=-1 :
        return '02'
    if nombre.find('Mar')!=-1 :
        return '03'
    if nombre.find('Apr')!=-1 or nombre.find('Abr')!=-1 :
        return '04'
    if nombre.find('May')!=-1 :
        return '05'
    if nombre.find('Jun')!=-1 :
        return '06'
    if nombre.find('Jul')!=-1 :
        return '07'
    if nombre.find('Aug')!=-1 or nombre.find('Ago')!=-1 :
        return '08'
    if nombre.find('Sep')!=-1 :
        return '09'
    if nombre.find('Oct')!=-1 :
        return '10'
    if nombre.find('Nov')!=-1 :
        return '11'
    if nombre.find('Dec')!=-1 or nombre.find('Dic')!=-1:
        return '12'
    else:
        return '00'
        
def dias_mes(mes):
    """Devuelve numero dias componen mes indicado"""
    nombre=mes.capitalize()

    if nombre.find('Jan')!=-1 or nombre.find('Ene')!=-1:
        return 30
    if nombre.find('Feb')!=-1:
        return 28
    if nombre.find('Mar')!=-1:
        return 31
    if nombre.find('Apr')!=-1 or nombre.find('Abr')!=-1:
        return 30
    if nombre.find('May')!=-1:
        return 31
    if nombre.find('Jun')!=-1:
        return 30
    if nombre.find('Jul')!=-1:
        return 31
    if nombre.find('Aug')!=-1 or nombre.find('Ago')!=-1:
        return 31
    if nombre.find('Sep')!=-1:
        return 30
    if nombre.find('Oct')!=-1:
        return 31
    if nombre.find('Nov')!=-1:
        return 30
    if nombre.find('Dec')!=-1 or nombre.find('Dic')!=-1:
        return 31
    else:
        return 0
        

