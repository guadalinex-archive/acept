#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

###Archivo crea directorios, archivos, actualiza fecha actual en fichero de configuracion
###y establece permisos adecuados en estructura de directorios tras la instalacion
###de la aplicacion

from inicSquid import inic_direct_users
from watcherSquid import examina_permisos
from func_blacklists import descomprime, inserta_blacklist, renuevadir
from func import *

import os, os.path
import shutil, commands
import time
from xml.dom import minidom

file_conf=archivo.configuracion

if not os.path.isdir('/etc/watcherCat') or not os.path.isfile('/etc/watcherCat/watcherconf.xml'):
	os.system('tar xvf /opt/caton/acept-1.1/etc_backup.tar -C / &>/dev/null')

SQdir=consulta_campo('dir_sq', file_conf)

if not os.path.isfile(SQdir+'/sbin/squid'):
	print 'Warning: Paquete squid-3.0-acept no ha sido instalado en el sistema'
	print 'Se aborta proceso post-instalacion, instale squid para continuar'
	f=open('/tmp/install_acept','w')
	f.write('error')
	f.close()
else:	
	if not os.path.isdir(SQdir+'/var'):
		os.makedirs(SQdir+'/var')

	if not os.path.isdir(SQdir+'/var/logs'):
		os.makedirs(SQdir+'/var/logs')

	if not os.path.isdir(SQdir+'/var/cache'):
		os.makedirs(SQdir+'/var/cache')

	if not os.path.isdir(SQdir+'/var/rg'):
		os.makedirs(SQdir+'/var/rg')

	SQGdir=consulta_campo('dir_sqg',file_conf)
	if not os.path.isdir(SQGdir):
		print 'Warning: Paquete squidguard-acept no ha sido instalado en el sistema'
		print 'Se aborta proceso post-instalacion, instale squidguard-acept para continuar'
		f=open('/tmp/install_acept','w')
		f.write('error')
		f.close()
	else:
		if not os.path.isdir(SQGdir+'/log'):
			os.makedirs(SQGdir+'/log')

		SARGdir=consulta_campo('sargrg',file_conf)
		if not os.path.isdir(SARGdir):
			print 'Warning: Paquete sarg no ha sido instalado en el sistema'
			print 'Se aborta proceso post-instalacion, instale sarg para continuar'
			f=open('/tmp/install_acept','w')
			f.write('error')
			f.close()
		else:
			if not os.path.isdir('/var/lib/squidguard'):
				os.makedirs('/var/lib/squidguard')
	
			if not os.path.isdir('/var/lib/squidguard/db'):
				os.makedirs('/var/lib/squidguard/db')

			if not os.path.isdir('/var/lib/squidguard/db/download'):
				os.makedirs('/var/lib/squidguard/db/download')
	
			if not os.path.isdir('/opt/caton/acept-1.1/estadisticas'):
				os.makedirs('/opt/caton/acept-1.1/estadisticas')

			if len(commands.getoutput('id squid 2>/dev/null | grep squid'))== 0:
				os.system('groupadd squid')
				os.system('useradd squid -g squid')


			#INSTALACION EN SISTEMA DE BLACKLISTS INCLUIDAS EN PAQUETE
			DBhome=consulta_campo('dbhome',file_conf)
			DLog=consulta_campo('logdir',file_conf)
			TMP=consulta_campo('tmpdir',file_conf)
			NLG=consulta_campo('filelog',file_conf)

			FileLog=DLog+'/'+NLG
			Ddown=DBhome+'/download'
			f_log=open(FileLog,'a')
	
			archivo='blacklists.tar.gz'

			renuevadir(TMP, f_log)

			origen='/opt/caton/acept-1.1/blacklists.tar.gz'
			destino=Ddown+'/'+archivo
			dest_tmp=TMP+'/'+archivo
	
			shutil.copyfile(origen, dest_tmp)
			shutil.copyfile(dest_tmp, destino)
			n=descomprime(archivo, TMP, dest_tmp)
			resultado=archivo[:n]
			fullpath=os.path.join(TMP, resultado)
			xmldoc=minidom.parse(file_conf)
			inserta_blacklist(fullpath, DBhome, resultado, xmldoc, f_log, file_conf )

			f=open(Ddown+'/.versiones','w')
			f.write(destino+'= Sat, 19 Nov 2005 00:37:06 GMT')	
			f.close()
			os.system('rm -rf /tmp/watch_blacklist')
			os.system('rm /opt/caton/acept-1.1/blacklists.tar.gz')

			#INCLUSION FECHA ACTUAL EN ARCHIVO DE CONFIGURACION
			date=time.localtime()
			act_date=time.strftime("%d%b%Y",date)
			act_update=time.strftime("%d/%m/%Y",date)
			act_fecha=time.strftime("%d %W %m %Y",date)
		
			actualiza_campo('last_update', act_update, file_conf)
			actualiza_campo('last_date',act_date,file_conf)
			actualiza_campo('fecha',act_fecha,file_conf)
	
			examina_permisos(file_conf)
			inic_direct_users(file_conf)


			
