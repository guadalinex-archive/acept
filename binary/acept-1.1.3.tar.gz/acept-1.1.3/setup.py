#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-
#
# Fichero:	setup.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 27 17:00:33 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)
#

from distutils.core import setup

setup(name='acept',
	version='1.1.3',
	description='Aplicacion para el control electronico de acceso a Internet',
	author='Maria D. Perez, Nestor Chacon Manzano',
	author_email='mshk@caton.es nchacon@caton.es',
	url='http://forja.guadalinex.org/repositorio/projects/acept/',
	long_description='Herramienta permite control del uso del ordenador que hacen los usuarios', 
	py_modules=["avanzado","ayuda","confSquid","func_blacklists","func_navegacion","func","informes","inicSquid","mefiGlobal","watcherMods","watcherSquid","wizard"],
	scripts=['acept.py','gui.py','instalacion.py','mefistofelina.py'],
	data_files=[('/etc/watcherCat',['config/watcherconf.xml','config/asocia_contenidos','config/limpia_iptables']),('/usr/squid/etc',['config/squid_acept.conf','config/sarg_acept.conf']),('/opt/caton/acept-1.1',['auth.py', 'informe.py', 'mas_info.py', 'mensaje.py', 'modelo.html', 'messages.pot', 'config/etc_backup.tar', 'config/blacklists.tar.gz']), ('/usr/share/applications',['config/acept.desktop'])],
	)
