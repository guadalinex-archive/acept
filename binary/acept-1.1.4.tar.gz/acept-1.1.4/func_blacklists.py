# -*- coding: ISO-8859-1 -*-
#
# Fichero:	func_blacklists.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 27 17:01:25 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)

###Archivo recoge modulos auxiliares para la actualizacion automatica de las blacklists

from mefiGlobal import *
from func import escribe_log
import os,os.path

##MODULO PARA ESTANDARIZACION DEL LENGUAJE
def _(cadena):
    return cadena
    
    
##MODULOS PARA ELIMINACION DE DIRECTORIOS
def rmgeneric(path, __func__):
    try:
        __func__(path)
    except OSError, (errno, strerror):
        print ERROR_STR % {'path': path, 'error': strerror}
    
    
def removeall(path,flog):
    """Elimina el contenido del directorio especificado, si no se trata de un directorio no hace nada"""
    if not os.path.isdir(path):
        return
    
    files=os.listdir(path)
    for x in files:
        fullpath=os.path.join(path,x)
        if os.path.isfile(fullpath):
            f=os.remove
            rmgeneric(fullpath,f)   
        elif os.path.isdir(fullpath):
            removeall(fullpath,flog)
            f=os.rmdir
            rmgeneric(fullpath,f)
            
    
##Modulo comprueba si directorio especificado existe
##si existe lo borra con todo su contenido
##creal el directorio
def renuevadir(nombre, flog):
    """Se crea directorio especificado, borrandolo antes si existia"""
    if os.path.exists(nombre):
        removeall(nombre,flog)
        os.rmdir(nombre)
    os.mkdir(nombre)
    
##Modulo crea directorio si no existe 
def creadir(nombre, flog):
    """Se crea directorio si no existia"""
    if os.path.exists(nombre)!=1:
        os.mkdir(nombre,0750)
   

##Modulo consulta fecha de version de archivo existente en el sistema
##Si no encuentra entrada para archivo devuelve -1
##devuelve fecha de version existente
def consulta_fecha(archivo,Ddown):
    """Devuelve fecha de version de archivo segun archivo de control de versiones, -1 si no se 
    ha descargado"""
    n=archivo.rfind('/')
    dbhome=archivo[:n]
    nombre=archivo[n+1:]
    #archivo registra version de fichero descargado
    f_version=Ddown+'/.versiones'
    f=open(f_version)
    flines=f.readlines()
    for i in range(len(flines)):
        if flines[i].find(nombre)!=-1:
            m=flines[i].find('=')
            fecha=flines[i][m+1:]
            f.close()
            return fecha
    
    f.close()
    return -1
    
##Modulo descarga archivo url
##comprueba si url responde ,si el objeto es de tipo aplicacion y si no se dispone de version mas reciente
##en caso afirmativo se descarga
def descarga (url,temporal,destino,Ddown,flog):
    """Descarga archivo si la url responde, es de tipo aplicacion y no se dispone ya de la version
    mas reciente"""
    import urllib
    #comprueba que la url responde, en caso contrario lo recoge en archivo de logs
    try:
        u=urllib.urlopen(url)
    except IOError:
        msj= _('Error al abrir url ')+url
        escribe_log(msj,flog)
        return -1
    
    #acceso a estructura que contiene informacion del objeto
    mdata=u.info() 
    
    #tipo de archivo debe ser application (tar.gz, gzip,...)
    #en caso contrario se considera acceso fallido
    tipo=mdata.get('Content-Type',0)
    if tipo.find('application')==-1:
        msj=_('Error al acceder a fuente ')+url
        escribe_log(msj,flog)
        return -1
    
    #se comprueba si el archivo fue descargado previamente
    #si lo fue se comprueba si la version descargada es mas reciente
    #fecha de version descargada
    nuevo=mdata.get('Last-Modified',0) 
    #fecha de version anterior en el sistema
    if os.path.exists(destino):
        actual=consulta_fecha(destino,Ddown)
        
        if actual!=-1: 
            #Compara fechas de versiones
            if actual.find(nuevo)!=-1:
                msj=_('Ya se dispone de fichero actualizado ')+url
                escribe_log(msj,flog)
                return -1
            else:
                msj=_('Detectada version mas actual de ')+url
                escribe_log(msj,flog)
                sustituye=1
            
        else:
            msj=_('Error: ')+destino+_(' no aparece en archivo versiones')
            escribe_log(msj,flog)
            sustituye=0
    else:
        sustituye=0
    
    msj=_('Se descarga archivo ')+url
    escribe_log(msj,flog)
    #Archivo se descarga/reemplaza, se registra su version en archivo de versiones
    file_ver=Ddown+'/.versiones'
    #sustituye entrada actual para dicho archivo
    if sustituye==0:
        f_ver=open(file_ver,'a')
        linea=destino+'='+nuevo+'\n'
        f_ver.write(linea)
        f_ver.close()
    else:
        #incluye nueva entrada para archivo
        f_ver=open(file_ver, 'r')
        flines=f_ver.readlines()
        f_ver.close()
        f_ver=open(file_ver,'w')
        for line in flines:
            if line.find(destino)!=-1:
                line=destino+'='+nuevo+'\n'
            f_ver.write(line)
            
        f_ver.close()
   
    urllib.urlcleanup() 
    urllib.urlretrieve(url,temporal)
        
    return 1
    
##Modulo que descomprime el archivo en directorio temporal 
##devuelve indice de cadena nombre en la que termina nombre de archivo 
##sin extension de compresion
def descomprime(nombre,DirTmp,archivo):
    """Descomprime archivo descargado segun el tipo de extension
    Se expera un archivo 'tar.gz' o '.gz'
    Si no se entiende el formato devuelve -1"""
    import commands
    
    if nombre.find('.tar.gz')!=-1 or nombre.find('.tgz')!=-1 :
        orden='tar zxvf'+' '+archivo+ ' -C'+DirTmp
        commands.getstatusoutput(orden)
        n=nombre.find('.t')
    elif nombre.find('.gz')!=-1:
        n_archivo=nombre[:nombre.find('.gz')]
        dest_desc=DirTmp+'/'+n_archivo
        orden='gunzip -c '+archivo+' > '+dest_desc
        commands.getstatusoutput(orden)
        n=nombre.find('.gz')
    else:
        #no se reconoce el formato de archivo: error al descomprimir
        return -1 
    return n
    
    
##Recibe nombre de grupo y una lista de grupos 
##Si alguno de los grupos de la lista tiene su valor de tag (etiqueta) 
##con el mismo nombre que el grupo proporcionado devuelve 1
##en caso contrario devuelve -1
def existe_grupo(nombre, grupos):
    """Comprueba si el nombre de grupo ya se encuentra entre la lista
    de grupos que se tiene"""
    for grupo in grupos:
        ngrupo=str(grupo.attributes["tag"].value)
        if nombre.find(ngrupo)!=-1 and ngrupo.find(nombre)!=-1:
            return 1
        
    return -1

##Funcion con la que se incluye un grupo que aun no se recogia en el archivo de configuracion  
##El grupo puede contener descripcion de: dominios, urls y/o expressiones
def append_grupo(grupo,descrip,f_obj,archivo,DBdest):
    """Se agrega grupo a archivo de configuracion, con las respectivas entradas
    que ese grupo engloba"""
    cad_domains='domains'
    cad_urls='urls'
    cad_expressions='expressions'
    nlista={'domains':0,'urls':0,'expressions':0}
    
    #comprueba descripciones que incluye el grupo
    for content in os.listdir(DBdest):
        if cad_domains.find(content)!=-1:
            nlista['domains']=1   
        elif cad_urls.find(content)!=-1:
            nlista['urls']=1   
        elif cad_expressions.find(content)!=-1:
            nlista['expressions']=1   
        
    
    #elemento dentro del que se inserta el grupo
    bl=f_obj.getElementsByTagName('blacklists')[0]

    tab=str(bl.firstChild.nodeValue)
    n=tab.rfind('\t')
    tab_padre=tab[:n]
    tab_hijo=tab+'\t'
    tab_hijo2=tab_hijo+'\t'

    ds=f_obj.createElement('descripcion')
    ds.appendChild(f_obj.createTextNode(tab_hijo2))
    ds.appendChild(f_obj.createTextNode(descrip))
    ds.appendChild(f_obj.createTextNode(tab_hijo))
    
    if nlista['domains']==1:
        dm=f_obj.createElement('entry')
        dm.setAttribute('tag','domains')

    if nlista['urls']==1:
        ur=f_obj.createElement('entry')
        ur.setAttribute('tag','urls')
    
    if nlista['expressions']==1:
        ex=f_obj.createElement('entry')
        ex.setAttribute('tag','expressions')
    
    gr=f_obj.createElement('group')    
    gr.appendChild(f_obj.createTextNode(tab_hijo))
    gr.appendChild(ds)
    if nlista['domains']==1:
        gr.appendChild(f_obj.createTextNode(tab_hijo))
        gr.appendChild(dm)
        
    if nlista['urls']==1:
        gr.appendChild(f_obj.createTextNode(tab_hijo))
        gr.appendChild(ur)
    
    if nlista['expressions']==1:
        gr.appendChild(f_obj.createTextNode(tab_hijo))
        gr.appendChild(ex)    
        
    gr.setAttribute('local','no')
    gr.setAttribute('tag',grupo)
    gr.appendChild(f_obj.createTextNode(tab))
    bl.appendChild(f_obj.createTextNode(tab))
    bl.appendChild(gr)
    bl.appendChild(f_obj.createTextNode(tab_padre))
    f=open(archivo,'w')
    f.write(f_obj.toxml())
    f.close()
    
##Modulo archivos de grupo en destino: 
##discrimina solo copiando los archivos que no son parches a versiones anteriores (.diff)    
def copia_grupo(orig,DBdest):
    """Copia contenido de grupo descargado, sin incluir archivos de parches y similares"""
    import shutil
    
    os.mkdir(DBdest)
    for obj in os.listdir(orig):
        if obj.find('.diff')==-1:
            origen=os.path.join(orig,obj)
            destino=os.path.join(DBdest,obj)
            shutil.copy(origen,destino)
 
    
##Modulo que inserta las blacklist descargadas de una url en el directorio
##temporal a la base de datos, a la vez que comprueba si los grupos que en
##ellas aparecen se recogen en la base de datos, si no es asi se incluyen en archivo
##de configuracion
def inserta_blacklist(fullpath,DBhome,nombre,xmldoc,flog,file_conf):
    """Inserta blacklists descargadas, incluyendo en archivo de configuracion
    grupos que no estuvieran considerados"""
    import shutil
    
    if os.path.isdir(fullpath): #listas descargadas contenidas en directorio
        files=os.listdir(fullpath) #se lista contenido directorio para tratarlo
        for x in files:
            DBdest=os.path.join(DBhome,x) #se compone destino
            orig=os.path.join(fullpath,x) #orig apunta a objeto a copiar
            if os.path.isdir(orig):  #directorio se copia completo y se comprueba si ya se tiene grupo
                if os.path.exists(DBdest):#si existia como directorio hay que eliminarlo
                    removeall(DBdest,flog)
                    os.rmdir(DBdest)
                #en lugar de copiar todo, solo copiar archivos principales
                copia_grupo(orig,DBdest)

                #se comprueba si ya se tiene incluido grupo en arch de configuracion
                grupos=xmldoc.getElementsByTagName('group')
                if existe_grupo(x,grupos)==-1 :# no existe hay que incluirlo
                    append_grupo(x,'',xmldoc,file_conf, DBdest)
                
            
            elif os.path.isfile(orig):#si es un archivo se copia salvo q se trate del README
                if x.find('README')!=-1:
                    continue
                shutil.copyfile(orig,DBdest)
            
    elif os.path.isfile(fullpath):
        DBdest=os.path.join(DBhome,nombre)
        shutil.copyfile(fullpath,DBdest)
        
