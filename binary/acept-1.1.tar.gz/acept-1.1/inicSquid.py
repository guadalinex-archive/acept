# -*- coding: ISO-8859-1 -*-
#
# Fichero:	inicSquid.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 20 19:21:29 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)

###Archivo contiene funciones para inicializacion de archivos configuran
###filtrado de contenido

from xml.dom import minidom
from func import *

##Modulo crea archivos de configuracion de squid para los usuarios del sistema
##a los que se les aplica configuracion se squid (algun filtrado de su acceso web)
def inic_squid_users(file_conf):
    """ Vierte configuracion de squid para los usuarios en los respectivos archivos de configuracion 
   para squid """
    import commands
   
    #toda la configuracion en archivo .xml
    xmldoc=minidom.parse(file_conf)
    #directorio donde se encuentra instalado squid
    SQdir=consulta_campo('dir_sq',file_conf)
    #archivo plantilla de configuracion de squid
    SQconf=consulta_campo('conf_sq',file_conf)
    #ruta donde se encuentra squidGuard
    SQguard=consulta_campo('sqguard',file_conf)

    usuarios=users_control_web(file_conf)

    squid_file=open(SQconf,'r')
    lines=squid_file.readlines()

    #obtiene nombre maquina en la que se trabaja
    hostname=commands.getoutput('hostname')
    
    #obtiene direccion IP publica de la maquina
    ip=commands.getoutput('/sbin/ifconfig eth0')
    ip=ip[ip.find('addr:')+5:]
    ip=ip[:ip.find(' ')]
                    
    for user in usuarios:
        #archivo de config de squid para user
        path=SQconf[:SQconf.rfind('/')]
        SQUSERconf=path+'/squid_'+user+'.conf'
        #abrir archivo squid que vamos a sobreescribir
        squ_file=open(SQUSERconf,'w')
        #puerto destinado para configuracion de squid de este usuario
        squ_port=squid_port_user(user,file_conf)
        #escribimos configuracion personalizando para el usuario 'user'
        for i in range(len(lines)):
            if lines[i].find('http_port')!=-1 and lines[i].find('#')==-1:
                squ_file.write('http_port '+squ_port+' transparent\n')
            elif lines[i].find('access_log')!=-1 and lines[i].find('#')==-1:
                squ_file.write('access_log '+SQdir+'/var/logs/'+user+'/access.log\n')
            elif lines[i].find('cache_log')!=-1 and lines[i].find('#')==-1:
                squ_file.write('cache_log '+SQdir+'/var/logs/'+user+'/cache.log\n')
            elif lines[i].find('cache_store_log')!=-1 and lines[i].find('#')==-1:
                squ_file.write('cache_store_log '+SQdir+'/var/logs/'+user+'/store.log\n')
            elif lines[i].find('pid_filename')!=-1 and lines[i].find('#')==-1:
                squ_file.write('pid_filename '+SQdir+'/var/logs/'+user+'/squid.pid\n')
            elif lines[i].find('redirect_program')!=-1 and lines[i].find('#')==-1:
                sqg_user='squidGuard_'+user+'.conf'
                squ_file.write('redirect_program '+SQguard+' -c '+SQdir+'/etc/'+sqg_user+'\n')
            elif lines[i].find('visible_hostname')!=-1 and lines[i].find('#')==-1:
                squ_file.write('visible_hostname '+hostname+'\n')
            elif lines[i].find('acl hostname')!=-1:
                squ_file.write('acl '+hostname+' src '+ip+'/32\n')
            elif lines[i].find('http_access allow hostname')!=-1:
                squ_file.write('http_access allow '+hostname+'\n')
            else:
                squ_file.write(lines[i])
        
        squ_file.close()
  
##Modulo crea archivos de configuracion de sarg para los usuarios del sistema
##a los que se les aplica configuracion se squid (algun filtrado de su acceso web)
def inic_sarg_users(file_conf):
    """Escribe archivos para configuracion de sarg para los usuarios con el servicio
    web filtrado"""
    #toda la configuracion en archivo .xml
    xmldoc=minidom.parse(file_conf)
    #directorio donde se encuentra instalado squid
    
    SQdir=consulta_campo('dir_sq',file_conf)
    #archivo plantilla de configuracion de sarg
    SARGconf=consulta_campo('conf_sarg',file_conf)
    #directorio donde se almancenan registros generados por sarg
    SARGdir=consulta_campo('sargrg',file_conf)
    
    usuarios=users_control_web(file_conf)

    sarg_file=open(SARGconf,'r')
    lines=sarg_file.readlines()

    for user in usuarios:
        #archivo de config de squid para user
        path=SARGconf[:SARGconf.rfind('/')]
        SARGUSERconf=path+'/sarg_'+user+'.conf'
        #abrir archivo squid que vamos a sobreescribir
        sgu_file=open(SARGUSERconf,'w')
        #escribimos configuracion personalizando para el usuario 'user'
        for i in range(len(lines)):
            if lines[i].find('access_log')!=-1 and lines[i].find('#')==-1:
                sgu_file.write('access_log '+SQdir+'/var/logs/'+user+'/access.log\n')
            elif lines[i].find('output_dir')!=-1 and lines[i].find('#')==-1:
                sgu_file.write('output_dir '+SARGdir+'/'+user+'\n')
            else:
                sgu_file.write(lines[i])
        
        sgu_file.close()

##Modulo que refleja la configuracion de squidguard definida en el archivo de configuracion xml
##en los archivos de los usuarios involucrados    
def apply_conf_squidguard(file_conf):
    """Vierte configuracion de filtrado de contenido para usuarios recogida en archivo de configuracion
    en correspondientes archivos con los que trabajaran las instancias de squidguard"""
    from xml import xpath
    
    xmldoc=minidom.parse(file_conf)
    
    #directorio donde se encuentra instalado squid
    SQdir=consulta_campo('dir_sq',file_conf)
    DBHOME=consulta_campo('dbhome',file_conf)
    LOGDIR=consulta_campo('logdir',file_conf)
    #extrae pag. muestra por defecto cuando acceso denegado a alguna url
    PAGE_DFL=consulta_campo('page_dfl',file_conf)
    
    usuarios=users_control_web(file_conf)

    for user in usuarios:
        #archivo de config de squidguard para user
        SQGconf=SQdir+'/etc/squidGuard_'+user+'.conf'
        #abrir archivo squidguard.conf que vamos a sobreescribir
        sqg_file=open(SQGconf,'w')

        sqg_file.write('dbhome '+DBHOME+'\n')
        sqg_file.write('logdir '+LOGDIR+'\n')

        sqg_file.write('\n#DESTINATION CLASSES\n')
        #inserta los grupos en la seccion DESTINATION CLASSES

        groups=xmldoc.getElementsByTagName('group')
        for grp in groups:
            nombre_group=str(grp.attributes["tag"].value)
            sqg_file.write('dest '+nombre_group+' {\n')
            for entry in grp.childNodes:
                if entry.localName:
                    if entry.localName.find('entry')!=-1:
                        tag=entry.attributes["tag"].value
                        sqg_file.write('\t '+tag[:-1]+'list \t'+nombre_group+'/'+tag+'\n')
            sqg_file.write('\n}\n')
 
        #inserta la lista blanca definida para el usuario
        sqg_file.write('dest white_'+user+' {\n')
        sqg_file.write('\t domainlist \t white_'+user+'/domains\n')
        sqg_file.write('\n}\n')
    
        sqg_file.write('\n #ACL DEFIITIONS\n')
        #inserta las acls en la seccion ACL DEFINITIONS

        sqg_file.write('acl {\n')
        sqg_file.write('\t default {\n')
        sqg_file.write('\t\t pass white_'+user)
        for list in xpath.Evaluate("/config/usuarios/"+user+"/web/denegado/*",xmldoc):
            sqg_file.write(' !'+str(list.attributes["tag"].value))   
        sqg_file.write('\n\t\t redirect '+PAGE_DFL+'\n\t}\n')
    
        sqg_file.write('}\n')
    
        sqg_file.close()
       
##Modulo examina si existen los directorios que se necesitan para el filtrado de contenido
##para cada usuario, si no existen se crean y se establecen los permisos adecuados
def inic_direct_users(file_conf):
    """Crea estructura para filtrado de contenido para usuarios para ls que se ha configurado
    con permisos correspondientes"""
    import os, os.path
    xmldoc=minidom.parse(file_conf)
    
    SQdir=consulta_campo('dir_sq',file_conf)
    SARGdir=consulta_campo('sargrg',file_conf)
    DBhome=consulta_campo('dbhome',file_conf)
    
    usuarios=users_control_web(file_conf)
    
    for user in usuarios:
        #comprobar si tiene su directorio de logs
        dlog=SQdir+'/var/logs/'+user
        if not os.path.isdir(dlog):
            os.system('mkdir '+dlog)
            fwdlog=dlog+'/access.log'
            f=open(fwdlog,'w')
            f.close()
        #comprobar si tiene su lista blanca creada, con archivo de dominios
        wlist=DBhome+'/white_'+user
        if not os.path.isdir(wlist):
            os.system('mkdir '+wlist)
            fwlist=wlist+'/domains'
            f=open(fwlist,'w')
            f.close()
        #comprobar si tiene su directorio para sarg
        sgdir=SARGdir+'/'+user
        if not os.path.isdir(sgdir):
            os.system('mkdir '+sgdir)        
        
    #cambiar permisos de directorios por si se han modificado
    permiso='chown -R squid:squid '
    os.system(permiso+SQdir)
    os.system(permiso+DBhome)
    os.system(permiso+SARGdir)
