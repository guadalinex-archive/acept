#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-
#
# Fichero:	instalacion.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 20 19:21:30 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)
#

###Archivo crea directorios, archivos, actualiza fecha actual en fichero de configuracion
###y establece permisos adecuados en estructura de directorios tras la instalacion
###de la aplicacion

from inicSquid import *
from watcherSquid import *
from func import actualiza_campo
import os, os.path
import time

file_conf=archivo.configuracion

if not os.path.isfile('/etc/watcherCat/watcherconf.xml'):
	os.system('tar xvf /opt/caton/acept-1.0/etc_backup.tar -C / &>/dev/null')

if not os.path.isdir('/usr/squid/var'):
	os.makedirs('/usr/squid/var')

if not os.path.isdir('/usr/squid/var/logs'):
	os.makedirs('/usr/squid/var/logs')

if not os.path.isdir('/usr/squid/var/cache'):
	os.makedirs('/usr/squid/var/cache')

if not os.path.isdir('/usr/squid/var/rg'):
	os.makedirs('/usr/squid/var/rg')

if not os.path.isdir('/usr/squidGuard/log'):
	os.makedirs('/usr/squidGuard/log')

if not os.path.isdir('/var/lib/squidguard'):
	os.makedirs('/var/lib/squidguard')

if not os.path.isdir('/var/lib/squidguard/db'):
	os.makedirs('/var/lib/squidguard/db')

if not os.path.isdir('/opt/caton/acept-1.0/estadisticas'):
	os.makedirs('/opt/caton/acept-1.0/estadisticas')


examina_permisos(file_conf)
inic_direct_users(file_conf)
ublacklists(file_conf)
inic_squid_users(file_conf)
inic_sarg_users(file_conf)
apply_conf_squidguard(file_conf)

date=time.localtime()
act_date=time.strftime("%d%b%Y",date)
act_update=time.strftime("%d/%m/%Y",date)
act_fecha=time.strftime("%d %W %m %Y",date)

actualiza_campo('last_update', act_update, file_conf)
actualiza_campo('last_date',act_date,file_conf)
actualiza_campo('fecha',act_fecha,file_conf)

examina_permisos(file_conf)
