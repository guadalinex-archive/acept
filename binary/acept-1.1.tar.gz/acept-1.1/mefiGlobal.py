# -*- coding: ISO-8859-1 -*-

#
# Fichero:	mefiGlobal.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 20 19:21:31 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)


""" Aqui se definen los objetos que tienen que poder modificarse desde cualquir punto del programa"""
#
# Clases

class glob:
    pass

# Bucle : Esta variable controla el while en mefistofelina.py que viene a ser el nucleo del programa.
# En caso de recibir un kill -15 se modifica a False.

# relee: al recibir un SIGCONT (18) el demonio vuelve a leer el archivo de configuracion
relee=glob()
relee.configuracion=False

archivo=glob()
archivo.configuracion='/etc/watcherCat/watcherconf.xml'
archivo.backup='/etc/watcherCat/watcherconf.bak'

pathAcept=glob()
pathAcept.path='/opt/caton/acept'

finaliza=glob()
finaliza.ya=False

actualizar=glob()
actualizar.config=False

indice=glob()
indice.matriz=0

tiempo=glob()
tiempo.aviso=10
tiempo.intervalo=2

usuari=glob()
usuari.id=""
usuari.serv=""

xy=glob()
xy.posicion=(0,0)

uid=glob()
uid.min="1000"

bl_lst=glob()
bl_lst.nombre=''

child=glob()
child.horarios=False
child.contenidos=False
child.servicios=False
child.listas=False
child.uso_web=False
child.uso_aplic=False
child.como=False

# Esta chapuza parece de microsoft
