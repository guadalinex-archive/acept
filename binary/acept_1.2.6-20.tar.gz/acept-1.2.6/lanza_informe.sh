#!/bin/bash

/usr/share/acept/informe.py $USER
