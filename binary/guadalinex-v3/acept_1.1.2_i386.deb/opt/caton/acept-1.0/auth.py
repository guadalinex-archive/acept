#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-
#
# Fichero:	auth.py
# Copyright:	Caton Sistemas Alternativos, 2006
# Autor:	Maria Dolores P�rez Guti�rrez y N�stor Chac�n Manzano
# Fecha:	lun mar 10 16:42:15 CET 2006
# Licencia:	GPL v.2
# Proyecto impulsado y financiado por SADESI (Sociedad Andaluza para el desarrollo de la Sociedad de la Informacion)
#
# Se usa para comprobar la salida de expect en "acept.py" y de esa manera comproba que se ha 
# introducido correctamente el password de root
print "Ok"
