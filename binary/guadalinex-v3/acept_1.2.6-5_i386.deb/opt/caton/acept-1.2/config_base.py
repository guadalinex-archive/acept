#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-
#
# Fichero: 	config_base.py
# Copyright: 	Junta de Andaluc�a <devmaster@guadalinex.org>
# Autor:   	Maria Dolores Perez Gutierrez, Nestor Chacon Manzano
# Fecha:	lun mar 23 20:32:00 CET 2006
# Licencia: 	GPL.v2
#
# Archivo crea directorios, archivos, actualiza fecha actual en fichero de configuracion
# y establece permisos adecuados en estructura de directorios tras la instalacion
# de la aplicacion

from inicSquid import inic_direct_users
from watcherSquid import examina_permisos,establece_permisos
from func_blacklists import descomprime, inserta_blacklists, renuevadir
from func import *

import os, os.path
import shutil, commands
import time
from func import parse_file

file_conf=archivo.configuracion
file_log=archivo.mefilog

#INSTALACION EN SISTEMA DE BLACKLISTS INCLUIDAS EN PAQUETE
DBhome=consulta_campo('dbhome',file_log)
DLog=consulta_campo('logdir',file_log)
TMP=consulta_campo('tmpdir',file_log)
NLG=consulta_campo('filelog',file_log)


FileLog=DLog+'/'+NLG
Ddown=DBhome+'/download'
os.system('echo 0.- %s' % FileLog)
f_log=open(FileLog,'a')

archivo='blacklists.tar.gz'
narchivo='http://ftp.teledanmark.no/pub/www/proxy/squidGuard/contrib/blacklists.tar.gz'

renuevadir(TMP, f_log)

origen='/opt/caton/acept-1.2/blacklists.tar.gz'
destino=Ddown+'/'+archivo
dest_tmp=TMP+'/'+archivo
	
shutil.copyfile(origen, dest_tmp)
shutil.copyfile(dest_tmp, destino)
resultado=descomprime(archivo, TMP, dest_tmp)
fullpath=os.path.join(TMP, resultado)
xmldoc=parse_file(file_conf)
inserta_blacklists(fullpath, DBhome, resultado, xmldoc, f_log, file_conf )

f=open(Ddown+'/.versiones','w')
f.write(narchivo+'= Sat, 19 Nov 2005 00:37:06 GMT\n')	
f.close()
os.system('rm -rf /tmp/watch_blacklist')
os.system('rm /opt/caton/acept-1.2/blacklists.tar.gz')

#INCLUSION FECHA ACTUAL EN ARCHIVO DE CONFIGURACION
date=time.localtime()
act_date=time.strftime("%d%b%Y",date)
act_update=time.strftime("%d/%m/%Y",date)
act_fecha=time.strftime("%d %W %m %Y",date)

actualiza_campo('last_update', act_update, file_log)
actualiza_campo('last_date',act_date,file_log)
actualiza_campo('fecha',act_fecha,file_log)

examina_permisos(file_conf)
inic_direct_users(file_log)
establece_permisos(file_conf)

			
