#!/bin/bash

/opt/caton/acept-1.2/informe.py $USER
